chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "startCookieClearer") {
  let alreadyCleared = false;

  function checkForTarget() {
    if (alreadyCleared) return;

    const target = document.querySelector("#__next > div.Layout_main-wrap__KzRPxo > main > div > div.Solution_solutionContainer__o8AMps > div.Solution_solutionMain__SYCF2Q > div.PCAnswerResult_answer-result__gCp2gu > div > div.Tabs_tabs-panel-wrap__EP9hZn > div:nth-child(1) > div > div > div > div.PCSolutionMask_Mask__aiEpdC > div");

    if (target) {
      alreadyCleared = true;
      chrome.runtime.sendMessage({ action: "clearCookies", origin: window.location.origin }, (response) => {
        if (response && response.success) {
          //alert("Cookies cleared for " + window.location.origin);
          location.reload(); // Reload the page after cookies are cleared
        }
      });
    }
  }

  checkForTarget();

  const observer = new MutationObserver(() => {
    checkForTarget();
  });
  observer.observe(document.body, { childList: true, subtree: true });

  // Clone the new element before deleting its parent
  const newElementParent = document.querySelector("#side-menu > div.SideMenuSmallCard_small-card__LHum0Z > div.SideMenuSmallCard_small-card-main__mCK1zD > div > div");
  const newElement = newElementParent ? newElementParent.querySelector("div.UpgradeSmallCard_title__MLfuXo > svg").cloneNode(true) : null;

  // Delete the specified elements
  const elementToDelete1 = document.querySelector("#__next > header > div > div.HeaderNext_h-account__k_uYX6 > div.HeaderNext_h-account-upgrade__dyd4zD");
  const elementToDelete2 = document.querySelector("#side-menu > div.SideMenuSmallCard_small-card__LHum0Z > div.SideMenuSmallCard_small-card-main__mCK1zD > div > div");
  if (elementToDelete1) elementToDelete1.remove();
  if (elementToDelete2) elementToDelete2.remove();

  // Append the new element
  const existingElement = document.querySelector("#__next > header > div > a");
  if (existingElement && newElement) {
    existingElement.appendChild(newElement);
  }
  }
});
