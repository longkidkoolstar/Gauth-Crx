const scriptName = "gauthmath-plus-unlocker";
const currentVersion = "1.1";
const API_KEY_PART1 = "3f44b67c-f51a-47cc-bd29-";
const API_KEY_PART2 = "20af308fbcb1";
const API_KEY = API_KEY_PART1 + API_KEY_PART2;
const PROTOCOL = "https://";
const DOMAIN = "api.jsonstorage.net";
const VERSION = "/v1/";
const RESOURCE_TYPE = "/json/";
const UNIQUE_ID = "d206ce58-9543-48db-a5e4-997cfc745ef3/";
const BASE_URL = PROTOCOL + DOMAIN + VERSION + RESOURCE_TYPE + UNIQUE_ID;
const ID = "3ae8fcf7-dcb7-487c-8509-bf6b9259f043";
const GET_URL = BASE_URL + ID + "?apiKey=" + API_KEY;
const UPDATE_URL = BASE_URL + ID + "?apiKey=" + API_KEY;

// Update checker constants
const META_PROTOCOL = "https://";
const META_DOMAIN = "api.jsonstorage.net";
const META_VERSION = "/v1/json/";
const META_UUID1 = "d206ce58-9543-48db-a5e4-997cfc745ef3/";
const META_UUID2 = "f283c91a-9d3b-40bc-a8b9-2bb62df565e1";
const META_API_KEY = "2e6d3341-7b1b-45e3-955b-97a50b48cede";
const META_BASE_URL = META_PROTOCOL + META_DOMAIN + META_VERSION + META_UUID1 + META_UUID2 + "?apiKey=" + META_API_KEY;

// Update checker function
const checkForUpdates = async () => {
    const CHECK_LIMIT = 5;
    const CHECK_INTERVAL = 24 * 60 * 60 * 1000 / CHECK_LIMIT; // Milliseconds between checks
    const storageKey = "lastUpdateCheck";
    const now = Date.now();

    // Initialize lastUpdateCheck if it doesn't exist
    if (!localStorage.getItem(storageKey)) {
        localStorage.setItem(storageKey, JSON.stringify({
            lastCheck: 0,
            checkCount: 0,
            lastDate: "",
        }));
    }

    try {
        const lastCheckData = JSON.parse(localStorage.getItem(storageKey));
        const lastCheck = lastCheckData.lastCheck || 0;
        const checkCount = lastCheckData.checkCount || 0;

        if (now - lastCheck >= CHECK_INTERVAL || lastCheckData.lastDate !== new Date().toDateString()) {
            if (lastCheckData.lastDate !== new Date().toDateString()) {
                lastCheckData.checkCount = 0;
            }

            if (lastCheckData.checkCount < CHECK_LIMIT) {
                const response = await fetch(META_BASE_URL);
                if (!response.ok) {
                    throw new Error(`Failed to fetch metadata. Status: ${response.status}`);
                }

                const metadata = await response.json();
                console.log("Received metadata:", metadata); // Debug log
                
                // Look for the extension metadata in the correct location
                const extensionData = metadata.extensions?.[scriptName];
                console.log("Extension data for", scriptName, ":", extensionData); // Debug log

                if (!extensionData?.version) {
                    console.error("Missing extension data in metadata:", metadata); // Debug log
                    throw new Error(`Extension "${scriptName}" not found in metadata or missing version information.`);
                }

                if (extensionData.version !== currentVersion) {
                    if (confirm(`A new version (${extensionData.version}) of "${scriptName}" is available!\n\nDo you want to update?`)) {
                        window.location.href = extensionData.crx_url;
                    }
                }

                localStorage.setItem(storageKey, JSON.stringify({
                    lastCheck: now,
                    checkCount: checkCount + 1,
                    lastDate: new Date().toDateString(),
                }));
            } else {
                console.warn("Update check limit reached for today.");
            }
        }
    } catch (error) {
        console.error("Update check failed:", error);
    }
};

const fetchJSON = async (url, options = {}) => {
  const response = await fetch(url, options);
  if (!response.ok) throw new Error(`Error: ${response.status}`);
  return await response.json();
};

const storage = {
  save: (key, value) => localStorage.setItem(key, JSON.stringify(value)),
  get: (key) => JSON.parse(localStorage.getItem(key)),
  remove: (key) => localStorage.removeItem(key),
  saveSession: (key, value) => sessionStorage.setItem(key, JSON.stringify(value)),
  getSession: (key) => JSON.parse(sessionStorage.getItem(key)),
  removeSession: (key) => sessionStorage.removeItem(key)
};

const calculateExpiryDate = (startDate, duration) => {
  const expiryDate = new Date(startDate);
  if (["lifetime", "inf"].includes(duration)) return null;
  const amount = parseInt(duration, 10);
  const unit = duration.replace(/\d+/g, '');
  switch (unit) {
    case 'd': expiryDate.setDate(expiryDate.getDate() + amount); break;
    case 'm': expiryDate.setMonth(expiryDate.getMonth() + amount); break;
    case 'y': expiryDate.setFullYear(expiryDate.getFullYear() + amount); break;
    case 'mi': expiryDate.setMinutes(expiryDate.getMinutes() + amount); break;
    default: throw new Error("Invalid duration format");
  }
  return expiryDate;
};

const verifyKey = async (key) => {
  try {
    const data = await fetchJSON(GET_URL);
    const keyData = data.keys[key];
    if (!keyData || (keyData.script && keyData.script !== scriptName)) {
      return { isValid: false };
    }
    const now = new Date();
    // Set the firstUse timestamp if not already set
    if (!keyData.firstUse) {
      keyData.firstUse = now.toISOString();
    }
    // Calculate expiry using the firstUse date instead of the current time
    const startDate = new Date(keyData.firstUse);
    const expiryDate = keyData.duration ? calculateExpiryDate(startDate, keyData.duration) : null;
    // Check if the key has expired
    if (expiryDate && now >= expiryDate) {
      keyData.expired = true;
      await fetchJSON(UPDATE_URL, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          keys: {
            [key]: keyData
          }
        })
      });
      return { isValid: false, error: 'Key has expired' };
    }
    // Check if the daily limit has been exceeded (using localStorage)
    const dailyLimit = 50;
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const storedRequests = storage.get('requests') || {};
    const requestsToday = storedRequests[today.toISOString()] || 0;
    if (requestsToday >= dailyLimit) {
      return { isValid: false, error: 'Daily limit exceeded' };
    }
    // If a lastUsed timestamp exists, reset the apiRequests if it's a new day
    if (keyData.lastUsed) {
      const lastUsedDate = new Date(keyData.lastUsed);
      if (lastUsedDate.toDateString() !== now.toDateString()) {
        keyData.apiRequests = 0;
      }
    }
    // Increment apiRequests and update version and lastUsed timestamp
    keyData.apiRequests = (keyData.apiRequests || 0) + 1;
    keyData.version = currentVersion;
    keyData.lastUsed = now.toISOString();
    // Update server-side data with the modified keyData (including firstUse if newly set)
    await fetchJSON(UPDATE_URL, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        keys: {
          [key]: keyData
        }
      })
    });
    // Update local request count for today
    storedRequests[today.toISOString()] = requestsToday + 1;
    storage.save('requests', storedRequests);
    return {
      isValid: true,
      expiry: expiryDate ? expiryDate.toISOString() : null,
      duration: keyData.duration
    };
  } catch (error) {
    console.error("Verification failed:", error);
    return { isValid: false };
  }
};

const checkLocalValidation = () => {
  const sessionData = storage.getSession('validation');
  if (!sessionData) return false;
  if (sessionData.expiry && new Date() >= new Date(sessionData.expiry)) {
    storage.removeSession('validation');
    storage.remove('userKey');
    return false;
  }
  return true;
};

(async () => {
  // Check for updates first
  await checkForUpdates();
  
  if (checkLocalValidation()) {
    chrome.runtime.sendMessage({ action: "startCookieClearer" });
    return;
  }
  let userKey = storage.get('userKey');
  if (!userKey) {
    userKey = prompt("Enter your license key:");
    if (!userKey) return alert("Key required!");
    storage.save('userKey', userKey);
  }
  const { isValid, expiry, error } = await verifyKey(userKey);
  if (!isValid) {
    storage.remove('userKey');
    if (error) {
      alert(error);
    } else {
      alert("Invalid key!");
    }
    return;
  }
  storage.saveSession('validation', {
    refreshed: true,
    expiry: expiry,
    timestamp: new Date().toISOString()
  });
  chrome.runtime.sendMessage({ action: "startCookieClearer" });
})();

