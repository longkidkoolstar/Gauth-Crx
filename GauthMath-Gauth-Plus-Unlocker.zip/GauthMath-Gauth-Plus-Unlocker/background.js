chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "clearCookies" && message.origin) {
      chrome.browsingData.remove(
        {
          origins: [message.origin],
          since: 0  // clear from the beginning of time
        },
        {
          cookies: true
        },
        () => {
          sendResponse({ success: true });
          // Send a message back to the content script to reload the page
          chrome.tabs.reload(sender.tab.id);
        }
      );
      return true; // Keep the message channel open for async response
  } else if (message.action === "startCookieClearer") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      chrome.tabs.sendMessage(tabs[0].id, { action: "startCookieClearer" });
  });
  }
});
